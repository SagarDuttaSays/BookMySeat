/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookmyseat.admin.model;

/**
 *
 * @author hp-pc
 */
public class Hall {
    private int id;
    private String p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20;
    private String s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19, s20, s21, s22, s23, s24, s25, s26, s27, s28, s29, s30, s31, s32, s33, s34, s35, s36, s37, s38, s39, s40, s41, s42, s43, s44, s45, s46, s47, s48, s49, s50, s51, s52, s53, s54, s55, s56, s57, s58, s59, s60, s61, s62, s63, s64, s65, s66, s67, s68, s69, s70, s71, s72, s73, s74, s75, s76, s77, s78, s79, s80;

    @Override
    public String toString() {
        return "Hall{" + "id=" + id + ", p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p4=" + p4 + ", p5=" + p5 + ", p6=" + p6 + ", p7=" + p7 + ", p8=" + p8 + ", p9=" + p9 + ", p10=" + p10 + ", p11=" + p11 + ", p12=" + p12 + ", p13=" + p13 + ", p14=" + p14 + ", p15=" + p15 + ", p16=" + p16 + ", p17=" + p17 + ", p18=" + p18 + ", p19=" + p19 + ", p20=" + p20 + ", s1=" + s1 + ", s2=" + s2 + ", s3=" + s3 + ", s4=" + s4 + ", s5=" + s5 + ", s6=" + s6 + ", s7=" + s7 + ", s8=" + s8 + ", s9=" + s9 + ", s10=" + s10 + ", s11=" + s11 + ", s12=" + s12 + ", s13=" + s13 + ", s14=" + s14 + ", s15=" + s15 + ", s16=" + s16 + ", s17=" + s17 + ", s18=" + s18 + ", s19=" + s19 + ", s20=" + s20 + ", s21=" + s21 + ", s22=" + s22 + ", s23=" + s23 + ", s24=" + s24 + ", s25=" + s25 + ", s26=" + s26 + ", s27=" + s27 + ", s28=" + s28 + ", s29=" + s29 + ", s30=" + s30 + ", s31=" + s31 + ", s32=" + s32 + ", s33=" + s33 + ", s34=" + s34 + ", s35=" + s35 + ", s36=" + s36 + ", s37=" + s37 + ", s38=" + s38 + ", s39=" + s39 + ", s40=" + s40 + ", s41=" + s41 + ", s42=" + s42 + ", s43=" + s43 + ", s44=" + s44 + ", s45=" + s45 + ", s46=" + s46 + ", s47=" + s47 + ", s48=" + s48 + ", s49=" + s49 + ", s50=" + s50 + ", s51=" + s51 + ", s52=" + s52 + ", s53=" + s53 + ", s54=" + s54 + ", s55=" + s55 + ", s56=" + s56 + ", s57=" + s57 + ", s58=" + s58 + ", s59=" + s59 + ", s60=" + s60 + ", s61=" + s61 + ", s62=" + s62 + ", s63=" + s63 + ", s64=" + s64 + ", s65=" + s65 + ", s66=" + s66 + ", s67=" + s67 + ", s68=" + s68 + ", s69=" + s69 + ", s70=" + s70 + ", s71=" + s71 + ", s72=" + s72 + ", s73=" + s73 + ", s74=" + s74 + ", s75=" + s75 + ", s76=" + s76 + ", s77=" + s77 + ", s78=" + s78 + ", s79=" + s79 + ", s80=" + s80 + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getP1() {
        return p1;
    }

    public void setP1(String p1) {
        this.p1 = p1;
    }

    public String getP2() {
        return p2;
    }

    public void setP2(String p2) {
        this.p2 = p2;
    }

    public String getP3() {
        return p3;
    }

    public void setP3(String p3) {
        this.p3 = p3;
    }

    public String getP4() {
        return p4;
    }

    public void setP4(String p4) {
        this.p4 = p4;
    }

    public String getP5() {
        return p5;
    }

    public void setP5(String p5) {
        this.p5 = p5;
    }

    public String getP6() {
        return p6;
    }

    public void setP6(String p6) {
        this.p6 = p6;
    }

    public String getP7() {
        return p7;
    }

    public void setP7(String p7) {
        this.p7 = p7;
    }

    public String getP8() {
        return p8;
    }

    public void setP8(String p8) {
        this.p8 = p8;
    }

    public String getP9() {
        return p9;
    }

    public void setP9(String p9) {
        this.p9 = p9;
    }

    public String getP10() {
        return p10;
    }

    public void setP10(String p10) {
        this.p10 = p10;
    }

    public String getP11() {
        return p11;
    }

    public void setP11(String p11) {
        this.p11 = p11;
    }

    public String getP12() {
        return p12;
    }

    public void setP12(String p12) {
        this.p12 = p12;
    }

    public String getP13() {
        return p13;
    }

    public void setP13(String p13) {
        this.p13 = p13;
    }

    public String getP14() {
        return p14;
    }

    public void setP14(String p14) {
        this.p14 = p14;
    }

    public String getP15() {
        return p15;
    }

    public void setP15(String p15) {
        this.p15 = p15;
    }

    public String getP16() {
        return p16;
    }

    public void setP16(String p16) {
        this.p16 = p16;
    }

    public String getP17() {
        return p17;
    }

    public void setP17(String p17) {
        this.p17 = p17;
    }

    public String getP18() {
        return p18;
    }

    public void setP18(String p18) {
        this.p18 = p18;
    }

    public String getP19() {
        return p19;
    }

    public void setP19(String p19) {
        this.p19 = p19;
    }

    public String getP20() {
        return p20;
    }

    public void setP20(String p20) {
        this.p20 = p20;
    }

    public String getS1() {
        return s1;
    }

    public void setS1(String s1) {
        this.s1 = s1;
    }

    public String getS2() {
        return s2;
    }

    public void setS2(String s2) {
        this.s2 = s2;
    }

    public String getS3() {
        return s3;
    }

    public void setS3(String s3) {
        this.s3 = s3;
    }

    public String getS4() {
        return s4;
    }

    public void setS4(String s4) {
        this.s4 = s4;
    }

    public String getS5() {
        return s5;
    }

    public void setS5(String s5) {
        this.s5 = s5;
    }

    public String getS6() {
        return s6;
    }

    public void setS6(String s6) {
        this.s6 = s6;
    }

    public String getS7() {
        return s7;
    }

    public void setS7(String s7) {
        this.s7 = s7;
    }

    public String getS8() {
        return s8;
    }

    public void setS8(String s8) {
        this.s8 = s8;
    }

    public String getS9() {
        return s9;
    }

    public void setS9(String s9) {
        this.s9 = s9;
    }

    public String getS10() {
        return s10;
    }

    public void setS10(String s10) {
        this.s10 = s10;
    }

    public String getS11() {
        return s11;
    }

    public void setS11(String s11) {
        this.s11 = s11;
    }

    public String getS12() {
        return s12;
    }

    public void setS12(String s12) {
        this.s12 = s12;
    }

    public String getS13() {
        return s13;
    }

    public void setS13(String s13) {
        this.s13 = s13;
    }

    public String getS14() {
        return s14;
    }

    public void setS14(String s14) {
        this.s14 = s14;
    }

    public String getS15() {
        return s15;
    }

    public void setS15(String s15) {
        this.s15 = s15;
    }

    public String getS16() {
        return s16;
    }

    public void setS16(String s16) {
        this.s16 = s16;
    }

    public String getS17() {
        return s17;
    }

    public void setS17(String s17) {
        this.s17 = s17;
    }

    public String getS18() {
        return s18;
    }

    public void setS18(String s18) {
        this.s18 = s18;
    }

    public String getS19() {
        return s19;
    }

    public void setS19(String s19) {
        this.s19 = s19;
    }

    public String getS20() {
        return s20;
    }

    public void setS20(String s20) {
        this.s20 = s20;
    }

    public String getS21() {
        return s21;
    }

    public void setS21(String s21) {
        this.s21 = s21;
    }

    public String getS22() {
        return s22;
    }

    public void setS22(String s22) {
        this.s22 = s22;
    }

    public String getS23() {
        return s23;
    }

    public void setS23(String s23) {
        this.s23 = s23;
    }

    public String getS24() {
        return s24;
    }

    public void setS24(String s24) {
        this.s24 = s24;
    }

    public String getS25() {
        return s25;
    }

    public void setS25(String s25) {
        this.s25 = s25;
    }

    public String getS26() {
        return s26;
    }

    public void setS26(String s26) {
        this.s26 = s26;
    }

    public String getS27() {
        return s27;
    }

    public void setS27(String s27) {
        this.s27 = s27;
    }

    public String getS28() {
        return s28;
    }

    public void setS28(String s28) {
        this.s28 = s28;
    }

    public String getS29() {
        return s29;
    }

    public void setS29(String s29) {
        this.s29 = s29;
    }

    public String getS30() {
        return s30;
    }

    public void setS30(String s30) {
        this.s30 = s30;
    }

    public String getS31() {
        return s31;
    }

    public void setS31(String s31) {
        this.s31 = s31;
    }

    public String getS32() {
        return s32;
    }

    public void setS32(String s32) {
        this.s32 = s32;
    }

    public String getS33() {
        return s33;
    }

    public void setS33(String s33) {
        this.s33 = s33;
    }

    public String getS34() {
        return s34;
    }

    public void setS34(String s34) {
        this.s34 = s34;
    }

    public String getS35() {
        return s35;
    }

    public void setS35(String s35) {
        this.s35 = s35;
    }

    public String getS36() {
        return s36;
    }

    public void setS36(String s36) {
        this.s36 = s36;
    }

    public String getS37() {
        return s37;
    }

    public void setS37(String s37) {
        this.s37 = s37;
    }

    public String getS38() {
        return s38;
    }

    public void setS38(String s38) {
        this.s38 = s38;
    }

    public String getS39() {
        return s39;
    }

    public void setS39(String s39) {
        this.s39 = s39;
    }

    public String getS40() {
        return s40;
    }

    public void setS40(String s40) {
        this.s40 = s40;
    }

    public String getS41() {
        return s41;
    }

    public void setS41(String s41) {
        this.s41 = s41;
    }

    public String getS42() {
        return s42;
    }

    public void setS42(String s42) {
        this.s42 = s42;
    }

    public String getS43() {
        return s43;
    }

    public void setS43(String s43) {
        this.s43 = s43;
    }

    public String getS44() {
        return s44;
    }

    public void setS44(String s44) {
        this.s44 = s44;
    }

    public String getS45() {
        return s45;
    }

    public void setS45(String s45) {
        this.s45 = s45;
    }

    public String getS46() {
        return s46;
    }

    public void setS46(String s46) {
        this.s46 = s46;
    }

    public String getS47() {
        return s47;
    }

    public void setS47(String s47) {
        this.s47 = s47;
    }

    public String getS48() {
        return s48;
    }

    public void setS48(String s48) {
        this.s48 = s48;
    }

    public String getS49() {
        return s49;
    }

    public void setS49(String s49) {
        this.s49 = s49;
    }

    public String getS50() {
        return s50;
    }

    public void setS50(String s50) {
        this.s50 = s50;
    }

    public String getS51() {
        return s51;
    }

    public void setS51(String s51) {
        this.s51 = s51;
    }

    public String getS52() {
        return s52;
    }

    public void setS52(String s52) {
        this.s52 = s52;
    }

    public String getS53() {
        return s53;
    }

    public void setS53(String s53) {
        this.s53 = s53;
    }

    public String getS54() {
        return s54;
    }

    public void setS54(String s54) {
        this.s54 = s54;
    }

    public String getS55() {
        return s55;
    }

    public void setS55(String s55) {
        this.s55 = s55;
    }

    public String getS56() {
        return s56;
    }

    public void setS56(String s56) {
        this.s56 = s56;
    }

    public String getS57() {
        return s57;
    }

    public void setS57(String s57) {
        this.s57 = s57;
    }

    public String getS58() {
        return s58;
    }

    public void setS58(String s58) {
        this.s58 = s58;
    }

    public String getS59() {
        return s59;
    }

    public void setS59(String s59) {
        this.s59 = s59;
    }

    public String getS60() {
        return s60;
    }

    public void setS60(String s60) {
        this.s60 = s60;
    }

    public String getS61() {
        return s61;
    }

    public void setS61(String s61) {
        this.s61 = s61;
    }

    public String getS62() {
        return s62;
    }

    public void setS62(String s62) {
        this.s62 = s62;
    }

    public String getS63() {
        return s63;
    }

    public void setS63(String s63) {
        this.s63 = s63;
    }

    public String getS64() {
        return s64;
    }

    public void setS64(String s64) {
        this.s64 = s64;
    }

    public String getS65() {
        return s65;
    }

    public void setS65(String s65) {
        this.s65 = s65;
    }

    public String getS66() {
        return s66;
    }

    public void setS66(String s66) {
        this.s66 = s66;
    }

    public String getS67() {
        return s67;
    }

    public void setS67(String s67) {
        this.s67 = s67;
    }

    public String getS68() {
        return s68;
    }

    public void setS68(String s68) {
        this.s68 = s68;
    }

    public String getS69() {
        return s69;
    }

    public void setS69(String s69) {
        this.s69 = s69;
    }

    public String getS70() {
        return s70;
    }

    public void setS70(String s70) {
        this.s70 = s70;
    }

    public String getS71() {
        return s71;
    }

    public void setS71(String s71) {
        this.s71 = s71;
    }

    public String getS72() {
        return s72;
    }

    public void setS72(String s72) {
        this.s72 = s72;
    }

    public String getS73() {
        return s73;
    }

    public void setS73(String s73) {
        this.s73 = s73;
    }

    public String getS74() {
        return s74;
    }

    public void setS74(String s74) {
        this.s74 = s74;
    }

    public String getS75() {
        return s75;
    }

    public void setS75(String s75) {
        this.s75 = s75;
    }

    public String getS76() {
        return s76;
    }

    public void setS76(String s76) {
        this.s76 = s76;
    }

    public String getS77() {
        return s77;
    }

    public void setS77(String s77) {
        this.s77 = s77;
    }

    public String getS78() {
        return s78;
    }

    public void setS78(String s78) {
        this.s78 = s78;
    }

    public String getS79() {
        return s79;
    }

    public void setS79(String s79) {
        this.s79 = s79;
    }

    public String getS80() {
        return s80;
    }

    public void setS80(String s80) {
        this.s80 = s80;
    }

    public Hall(int id, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10, String s11, String s12, String s13, String s14, String s15, String s16, String s17, String s18, String s19, String s20, String s21, String s22, String s23, String s24, String s25, String s26, String s27, String s28, String s29, String s30, String s31, String s32, String s33, String s34, String s35, String s36, String s37, String s38, String s39, String s40, String s41, String s42, String s43, String s44, String s45, String s46, String s47, String s48, String s49, String s50, String s51, String s52, String s53, String s54, String s55, String s56, String s57, String s58, String s59, String s60, String s61, String s62, String s63, String s64, String s65, String s66, String s67, String s68, String s69, String s70, String s71, String s72, String s73, String s74, String s75, String s76, String s77, String s78, String s79, String s80) {
        this.id = id;
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
        this.s4 = s4;
        this.s5 = s5;
        this.s6 = s6;
        this.s7 = s7;
        this.s8 = s8;
        this.s9 = s9;
        this.s10 = s10;
        this.s11 = s11;
        this.s12 = s12;
        this.s13 = s13;
        this.s14 = s14;
        this.s15 = s15;
        this.s16 = s16;
        this.s17 = s17;
        this.s18 = s18;
        this.s19 = s19;
        this.s20 = s20;
        this.s21 = s21;
        this.s22 = s22;
        this.s23 = s23;
        this.s24 = s24;
        this.s25 = s25;
        this.s26 = s26;
        this.s27 = s27;
        this.s28 = s28;
        this.s29 = s29;
        this.s30 = s30;
        this.s31 = s31;
        this.s32 = s32;
        this.s33 = s33;
        this.s34 = s34;
        this.s35 = s35;
        this.s36 = s36;
        this.s37 = s37;
        this.s38 = s38;
        this.s39 = s39;
        this.s40 = s40;
        this.s41 = s41;
        this.s42 = s42;
        this.s43 = s43;
        this.s44 = s44;
        this.s45 = s45;
        this.s46 = s46;
        this.s47 = s47;
        this.s48 = s48;
        this.s49 = s49;
        this.s50 = s50;
        this.s51 = s51;
        this.s52 = s52;
        this.s53 = s53;
        this.s54 = s54;
        this.s55 = s55;
        this.s56 = s56;
        this.s57 = s57;
        this.s58 = s58;
        this.s59 = s59;
        this.s60 = s60;
        this.s61 = s61;
        this.s62 = s62;
        this.s63 = s63;
        this.s64 = s64;
        this.s65 = s65;
        this.s66 = s66;
        this.s67 = s67;
        this.s68 = s68;
        this.s69 = s69;
        this.s70 = s70;
        this.s71 = s71;
        this.s72 = s72;
        this.s73 = s73;
        this.s74 = s74;
        this.s75 = s75;
        this.s76 = s76;
        this.s77 = s77;
        this.s78 = s78;
        this.s79 = s79;
        this.s80 = s80;
    }

    public Hall(int id, String p1, String p2, String p3, String p4, String p5, String p6, String p7, String p8, String p9, String p10, String p11, String p12, String p13, String p14, String p15, String p16, String p17, String p18, String p19, String p20) {
        this.id = id;
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
        this.p5 = p5;
        this.p6 = p6;
        this.p7 = p7;
        this.p8 = p8;
        this.p9 = p9;
        this.p10 = p10;
        this.p11 = p11;
        this.p12 = p12;
        this.p13 = p13;
        this.p14 = p14;
        this.p15 = p15;
        this.p16 = p16;
        this.p17 = p17;
        this.p18 = p18;
        this.p19 = p19;
        this.p20 = p20;
    }

    public Hall() {
    }
    
}
